from fastapi.security import HTTPBearer

bearer_scheme = HTTPBearer() 